#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <curl/curl.h>
#include <nlohmann/json.hpp>

using namespace std;
using json = nlohmann::json;

struct Article {
    string name;
    int comments;
};


size_t writeData(void* ptr, size_t size, size_t nmemb, string* data) {
    data->append((char*)ptr, size * nmemb);
    return size * nmemb;
}
string getData(int page) {
    CURL* curl = curl_easy_init();
    string result;
    if (curl) {
        string url = "https://jsonmock.hackerrank.com/api/articles?page=" + to_string(page);
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeData);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &result);
        curl_easy_perform(curl); 
        curl_easy_cleanup(curl);
    }
    return result;
}
vector<string> topArticles(int limit) {
    vector<Article> list;
    int page = 1;
    int totalPages = 1;
    while (page <= totalPages) {
        string response = getData(page);
        if (response.empty()) break;
        json data = json::parse(response);
        totalPages = data["total_pages"];
        for (auto item : data["data"]) {
            string title = "";  
            if (!item["title"].is_null())
                title = item["title"];
            else if (!item["story_title"].is_null())
                title = item["story_title"];
            else
                continue;
            int comments = 0;
            if (!item["num_comments"].is_null())
                comments = item["num_comments"];
            list.push_back({title, comments});
        }
        page++;
    }
    sort(list.begin(), list.end(), [](Article a, Article b) {
        if (a.comments != b.comments)
            return a.comments > b.comments;
        return a.name > b.name;
    });
    vector<string> result;
    for (int i = 0; i < limit && i < list.size(); i++) {
        result.push_back(list[i].name);
    }
    return result;
}