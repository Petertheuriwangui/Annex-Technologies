#include <stdio.h>
#include <stdlib.h>
#include <math.h>
long pthFactor(long n, long p) {
    if (n <= 0 || p <= 0) return 0;
    long limit = sqrt(n);
    long *smallFactors = (long *)malloc(limit * sizeof(long));
    long *largeFactors = (long *)malloc(limit * sizeof(long));
    if (!smallFactors || !largeFactors) {
        return 0;
    }
    long smallCount = 0;
    long largeCount = 0;
    for (long i = 1; i <= limit; i++) {
        if (n % i == 0) {
            smallFactors[smallCount++] = i;

            if (i != n / i) {
                largeFactors[largeCount++] = n / i;
            }
        }
    }
    long totalFactors = smallCount + largeCount;
    if (p > totalFactors) {
        free(smallFactors);
        free(largeFactors);
        return 0;
    }
    long result;
    if (p <= smallCount) {
        result = smallFactors[p - 1];
    } else {
        result = largeFactors[largeCount - (p - smallCount)];
    }
    free(smallFactors);
    free(largeFactors);
    return result;
}